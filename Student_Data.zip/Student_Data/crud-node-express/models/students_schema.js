const mongoose = require('mongoose') 
const Schema = mongoose.Schema    //schema definition

const studentSchema = new Schema({
      
     name:{ type: String, required: true },   
     age:{ type: String, required: true },   
     course:{type:String,required: true},
     yearOfCompletion:{type:String,required: true}
   
})

var studentdata = mongoose.model('student_tb',studentSchema) //model creation
module.exports=studentdata;