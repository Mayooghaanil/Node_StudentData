const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const studentdata = require('./models/students_schema');

const app = express();

app.use(bodyParser.urlencoded({ extended: true }))

app.use(bodyParser.json())

// mongoose.connect("mongodb+srv://user_1:mayoogha@123@cluster0.mfxbmlw.mongodb.net/",()=>{
//     console.log("Connected")
// })
// mongoose.Promise = global.Promise;

mongoose.connect("mongodb+srv://user_1:mayoogha%40123@cluster0.mfxbmlw.mongodb.net/student?retryWrites=true&w=majority/", {
    useNewUrlParser: true
}).then(() => {
    console.log("Databse Connected Successfully!!");    
}).catch(err => {
    console.log('Could not connect to the database', err);
    process.exit();
});
app.post('/r', (req, res) => {
    const student={
        name:"Mayoogha",
        age:"20",
        course:"Bca",
        yearOfCompletion:"2019"
    }
    var studentModel=new studentdata(student)
    studentModel.save().then(()=>{
        res.json({"message": "Data save"});

    })
    
});
app.get('/get_data', (req, res) => {
    studentdata.find().then((data)=>{
        // res.json({"message": "Hello Crud Node Express"});
        console.log(data)
    });
   
});

app.post('/add_student', ((req, res) => {
    console.log(req.body);
    var item = new studentdata ({
        name: req.body.name,
        age: req.body.age,
        course: req.body.course,
        yearOfCompletion: req.body.yearOfCompletion,

    })
    console.log(item);
    // var students = studentdata(item);
    item.save().then(() => {
        res.status(200).json({
            success: true,
            error: false,
            message: 'Message  Sended!'
        })
    })
        .catch(err => {
            return res.status(401).json({
                message: "Something went wrong"
            })
        })
}))

app.delete('/delete_data/:id', ((req, res) => {
  const id=req.params.id 
  studentdata.deleteOne({_id:id}).then(() => {
    console.log("remove data")
    res.status(200).json({
        success: true,
        error: false,
        message: 'Student deleteed'
    })
})

app.post('/update_student/:id', ((req, res) => {
    const id = req.params.id
    console.log(id);
    studentdata.updateOne(  { _id:id} , { $set: { name : "name"  } } ).then((user)=>{
        console.log(user);
        res.status(200).json({
            success:true,
            error:false,
            message:"Student updated"
        })
        
    })
 
}))

}))
app.listen(3000, () => {
    console.log("Server is listening on port 3000");
});